# Qurat Ali — Ain Graphics (Portfolio Website)

A fast, single-file portfolio website for **Qurat Ali** (Content Creator · Graphic Designer · AI Creator), Multan, Pakistan.

## What is inside
- `index.html` — the complete website. All pages (Home, Portfolio, Services, About, Contact), styles, scripts and images are inside this one file, so nothing else is needed.

## Publish on GitHub Pages (free)
1. Sign in to GitHub and click **New repository**. Name it, for example, `aingraphics` (or `username.github.io` for a main site address). Keep it **Public**.
2. Click **Add file → Upload files**, drag in `index.html`, then **Commit changes**.
3. Open **Settings → Pages**. Under *Build and deployment*, choose **Deploy from a branch**, select branch **main** and folder **/ (root)**, then **Save**.
4. Wait a minute. Your site will be live at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Easy edits (open `index.html` in any text editor)
- **WhatsApp number:** search for `923004879550` and replace it with the new number (country code first, no `+` or `00`). Also update the visible number `+92 300 4879550`.
- **Name, city, text:** search for the words you want to change, for example `Multan` or `Ain Graphics`.
- **Colours:** change the colour values near the top of the `<style>` section (maroon `#6B0F1A`, `#A31D32`, dark `#3A0710`, gold `#C9A24B`, `#F0D98F`).
- **Time zone of the clock:** search for `Asia/Karachi`.

## Custom domain (optional)
Buy a domain such as `quratali.com`, then in **Settings → Pages → Custom domain** add it and follow GitHub's DNS instructions.

## Notes
- Works on phones and computers, and respects the visitor's reduced-motion setting.
- Fonts (Sora, DM Sans) load from Google Fonts. Without internet the site falls back to system fonts.
